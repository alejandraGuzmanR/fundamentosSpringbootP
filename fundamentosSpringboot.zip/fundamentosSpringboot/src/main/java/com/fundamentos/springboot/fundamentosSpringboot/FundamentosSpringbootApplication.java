package com.fundamentos.springboot.fundamentosSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FundamentosSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(FundamentosSpringbootApplication.class, args);
	}

}
