package com.fundamentos.springboot.fundamentosSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundamentosSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
